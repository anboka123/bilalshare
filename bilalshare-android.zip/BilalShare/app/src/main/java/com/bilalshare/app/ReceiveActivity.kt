package com.bilalshare.app

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ReceiveActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val uri = intent.getParcelableExtra<android.net.Uri>(Intent.EXTRA_STREAM)

        if (uri != null) {
            Toast.makeText(this, "Received: $uri", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "No data received", Toast.LENGTH_SHORT).show()
        }

        finish()
    }
}
